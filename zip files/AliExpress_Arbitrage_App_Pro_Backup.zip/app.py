import streamlit as st
from utils import fetch_products, generate_description, save_results, fetch_ebay_comparison

st.set_page_config(page_title="AliExpress Arbitrage Finder Pro", layout="wide", page_icon="🛍️")
st.title("🛍️ AliExpress Arbitrage Finder Pro")

keyword = st.text_input("Enter a product keyword (e.g. 'air fryer'):")

filter_price = st.selectbox("Filter by price:", ["No filter", "Low to High", "High to Low"])
filter_rating = st.selectbox("Minimum rating:", ["No filter", "4.0", "4.5", "4.8"])

if keyword:
    with st.spinner("Searching AliExpress..."):
        products = fetch_products(keyword)

        if filter_rating != "No filter":
            products = [p for p in products if float(p['rating']) >= float(filter_rating)]
        if filter_price == "Low to High":
            products = sorted(products, key=lambda x: float(x['price'].strip('$')))
        elif filter_price == "High to Low":
            products = sorted(products, key=lambda x: float(x['price'].strip('$')), reverse=True)

        if products:
            st.success(f"Found {len(products)} products")
            for product in products:
                col1, col2 = st.columns([1, 2])
                with col1:
                    st.image(product["image"], width=150)
                with col2:
                    st.markdown(f"### {product['title']}")
                    st.markdown(f"💲 **AliExpress Price**: {product['price']} | ⭐ {product['rating']}")
                    st.markdown(f"[🔗 View Product]({product['link']})")

                    if st.button(f"Generate AI Description for {product['title'][:30]}", key=product["link"]):
                        description = generate_description(product["title"], product.get("features", ""))
                        st.info(description)

                    ebay = fetch_ebay_comparison(product['title'])
                    st.markdown("---")
                    st.markdown(f"**eBay Price Estimate**: {ebay['price']}")
                    st.markdown(f"[🔎 View on eBay]({ebay['link']})")

            if st.button("📥 Save Results to CSV"):
                save_results(products)
                st.success("Saved to results.csv")
        else:
            st.error("No products found.")
