
1. Open 'alerts.csv' and update with your product URLs and target prices.
2. Set up 'email_config.json' with your Outlook email and app password.
3. Run the script with: python price_alerts.py
4. You'll get an email if any prices drop below your target.
