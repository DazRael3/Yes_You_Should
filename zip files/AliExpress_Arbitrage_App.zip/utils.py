import requests
import csv
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY", "your_openai_api_key_here")

def fetch_products(keyword):
    # Fake scraping stub (replace with actual API or scraping)
    return [
        {
            "title": f"{keyword.title()} Pro Model",
            "price": "$39.99",
            "rating": "4.7",
            "image": "https://via.placeholder.com/150",
            "link": "https://aliexpress.com/item/123",
            "features": "Modern design, Energy efficient, Easy to use"
        },
        {
            "title": f"{keyword.title()} Basic Model",
            "price": "$29.99",
            "rating": "4.4",
            "image": "https://via.placeholder.com/150",
            "link": "https://aliexpress.com/item/456",
            "features": "Compact, Lightweight, Budget friendly"
        }
    ]

def generate_description(title, features):
    prompt = f"Write an engaging product description for a product titled '{title}' with these features: {features}"
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=150
    )
    return response.choices[0].message["content"].strip()

def save_results(products):
    keys = ["title", "price", "rating", "link"]
    with open("results.csv", "w", newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for p in products:
            writer.writerow({k: p[k] for k in keys})
