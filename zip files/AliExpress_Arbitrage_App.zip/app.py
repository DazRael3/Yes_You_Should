import streamlit as st
from utils import fetch_products, generate_description, save_results

st.set_page_config(page_title="AliExpress Arbitrage Finder", layout="centered", page_icon="🛒")

st.title("🛍️ AliExpress Arbitrage Finder (Local + Free)")
keyword = st.text_input("Enter a product keyword (e.g. air fryer):")

if keyword:
    with st.spinner("🔍 Searching AliExpress..."):
        products = fetch_products(keyword)
        if products:
            st.success(f"Found {len(products)} products!")
            for product in products:
                st.image(product["image"], width=150)
                st.markdown(f"**{product['title']}**")
                st.markdown(f"💲 Price: {product['price']} | ⭐ {product['rating']}")
                st.markdown(f"[🔗 View Product]({product['link']})")

                if st.button(f"Generate Description for {product['title'][:30]}...", key=product["link"]):
                    description = generate_description(product["title"], product.get("features", ""))
                    st.markdown(f"**AI Description:** {description}")

            if st.button("📥 Save All Results to CSV"):
                save_results(products)
                st.success("CSV saved as 'results.csv'!")
        else:
            st.error("No products found.")
