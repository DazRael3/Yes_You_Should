
AliExpress Arbitrage Finder Pro

This version includes:
- AI-generated product descriptions using GPT-4
- Simulated eBay price comparisons
- Ready for price alerts and auto-scans (next steps)

To run:
1. Install dependencies: pip install -r requirements.txt
2. Run the app: streamlit run app.py
